<?php

return [
    'title' => 'Member Registration Success',
    'text1' => 'Congratulations!',
    'text2' => 'You have successfully registered: ',
    'back' => 'Back to registration'
];
