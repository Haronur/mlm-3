<?php

return [
	'title' => 'Unilevel Hierarchy',
	'subTitle' => 'Unilevel (Direct Member) Network. Empty means no direct member.',
	'member' => 'Member ID',
	'secret' => 'Security Password',
	'notice' => 'Please input ID first.',
    'modal.title' => 'Member Detail',
    'modal.info' => 'Member Information',
    'modal.id' => 'User ID',
    'modal.join' => 'Join Date',
    'modal.package' => 'Package',
    'modal.sponsor' => 'Sponsor',
    'modal.totalSales' => 'Total Sales'
];
