<?php

return [
'title'	=>	'Login',
'subtitle' => 'Welcome | MEMBER AREA',
'username' => 'Username',
'password' => 'Password',
'remember' => 'Remember Me'
];