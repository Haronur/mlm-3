<?php

return [
	'title'	=>	'Dashboard',
	'direct' => 'Direct Members',
	'total' => 'Total Sales'
];
