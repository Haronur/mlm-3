<?php

return [
	'title'	=>	'Dashboard',
	'direct' => 'Direct Members',
	'total' => 'Total Sales',
    'rateTitle' => 'Exchange Rate',
    'rateSub' => 'Overview of the current exchange rate.',
    'rateCountry' => 'Country',
    'rateCurrency' => 'Currency',
    'rateBuy' => 'Buy IN',
    'rateSell' => 'Sell OUT',
];
