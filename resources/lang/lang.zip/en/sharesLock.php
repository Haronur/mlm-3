<?php

return [
	'title' => 'Shares Lock Statement',
	'subTitle' => 'Your locked shares.',
	'create' => 'Created Date',
	'active' => 'Active Date',
	'amount' => 'Amount',
	'process' => 'Has Process'
];
