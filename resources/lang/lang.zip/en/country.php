<?php

return [
    'Cambodia' => 'Cambodia',
    'China' => 'China',
    'Indonesia' => 'Indonesia',
    'Malaysia' => 'Malaysia',
    'Philippines' => 'Philippines',
    'Singapore' => 'Singapore',
    'Thailand' => 'Thailand',
    'Taiwan' => 'Taiwan',
    'Vietnam' => 'Vietnam',
    'selected' => 'Selected Country'
];
