<?php

return [
	'title' => 'Upgrade / Renew Package',
	'subTitle' => '<span class="text-warning bold">10-50%</span> of your promotion point, <span class="text-warning bold">50-90%</span> of your register point.', // don't remove <span></span>
	'package' => 'Package',
	'renew' => 'RENEW',
	'registerPoint' => 'REGISTER POINT amount',
	'registerNotice' => 'will be used on promotion point.' // like "90% will be used on promotion point"
];
