<?php

return [
	'title' => '积分交易中心',
	'subTitle' => '注册积分, 优惠积分, 或 现金积分转移',
	'transfer' => '积分转移',
	'amount' => '数额',
	'amountNotice' => '必须是10的倍数.',
	'target' => '转移至',
	'targetNotice' => '请区分大小写',
	'security' => '安全密码'
];
