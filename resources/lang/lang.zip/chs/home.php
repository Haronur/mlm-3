<?php

return [
	'title' => '会员专区',
    'direct' => 'Direct Members',
    'total' => 'Total Sales'
];
