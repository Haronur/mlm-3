<?php

return [
	'title' => '会员专区',
    'direct' => 'Direct Members',
    'total' => 'Total Sales',
    'rateTitle' => '兑换率',
    'rateSub' => '兑换率报表',
    'rateCountry' => '国家',
    'rateCurrency' => '货币',
    'rateBuy' => '买入',
    'rateSell' => '卖出'
];
