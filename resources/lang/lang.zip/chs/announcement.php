<?php

return [
    'title' => '公司公告',
    'listDate' => '创建日期',
    'listTitle' => '标题',
    'listAction' => '状态'
];
