<?php

return [
	'title' => '会员注册记录',
	'subTitle' => '您的直接推荐注册记录。',
	'join' => '参与日期',
	'username' => '账号',
	'package' => '配套',
	'action' => '活跃'
];
