<?php

return [
	'title' => '推荐人架构',
	'subTitle' => '推荐人架构， 空白为不存在直接推荐人。',
	'member' => '账户',
	'secret' => '安全密码',
	'notice' => '请先输入账户名。',
    'modal.title' => 'Member Detail',
    'modal.info' => 'Member Information',
    'modal.id' => 'User ID',
    'modal.join' => 'Join Date',
    'modal.package' => 'Package',
    'modal.sponsor' => 'Sponsor',
    'modal.totalSales' => 'Total Sales'
];
