<?php

return [
	'loginSuccess'		=>	'成功登入。',
    'registerSuccess'   =>  '成功注册会员。',
    'upgradeSuccess'	=>	'配套升级/重购成功。',
    'transferSuccess'	=>	'积分转移成功。',
    'sharesBuySuccess'	=>	'MD积分买入成功。',
    'sharesSellSuccess'	=>	'MD积分卖出成功。',
    'withdrawSuccess'	=>	'提现申请成功。',
    'accountUpdateSuccess'	=>	'会员资料已更新。'
];
