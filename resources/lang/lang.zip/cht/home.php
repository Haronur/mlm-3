<?php

return [
	'title' => '會員專區',
    'direct' => 'Direct Members',
    'total' => 'Total Sales'
];
