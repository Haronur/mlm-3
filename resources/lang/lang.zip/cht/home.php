<?php

return [
	'title' => '會員專區',
    'direct' => 'Direct Members',
    'total' => 'Total Sales',
    'rateTitle' => '兌換率',
    'rateSub' => '兌換率報表',
    'rateCountry' => '國家',
    'rateCurrency' => '貨幣',
    'rateBuy' => '買入',
    'rateSell' => '賣出'
];
