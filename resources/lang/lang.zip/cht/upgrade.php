<?php

return [
	'title' => '升級 / 重購配套',
	'subTitle' => '需用<span class="text-warning bold">100%</span>註冊積分支付。', // don't remove <span></span>
	'package' => '配套',
	'renew' => '重購',
	'registerPoint' => '將用註冊積分支付',
	'registerNotice' => '將用優惠積分支付' // like "90% will be used on promotion point"
];
