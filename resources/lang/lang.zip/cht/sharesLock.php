<?php

return [
	'title' => 'MD積分（鎖）報表',
	'subTitle' => 'MD積分（锁）。',
	'create' => '創立日期',
	'active' => '開通日期',
	'amount' => '數額',
	'process' => '當前狀態'
];
