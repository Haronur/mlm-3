<?php

return [
	'title' => '提現記錄',
	'subTitle' => '提現記錄',
	'create' => '創立日期',
	'amount' => '數額',
    'adminFee' => '管理費',
	'status' => '狀態'
];
