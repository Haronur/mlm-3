<?php

return [
    'title' => '公司通告',
    'listDate' => '創建日期',
    'listTitle' => '標題',
    'listAction' => '狀態'
];
