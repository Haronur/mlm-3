<?php

return [
	'title' => '會員註冊記錄',
	'subTitle' => '您的直接推薦註冊記錄。',
	'join' => '加入日期',
	'username' => '賬號',
	'package' => '配套',
	'action' => '活躍'
];
